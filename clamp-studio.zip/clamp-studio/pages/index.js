import dynamic from 'next/dynamic';

// Dynamically import the ClampStudio component to avoid server-side rendering errors
const ClampStudio = dynamic(() => import('../components/ClampStudio'), { ssr: false });

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      <ClampStudio />
    </div>
  );
}